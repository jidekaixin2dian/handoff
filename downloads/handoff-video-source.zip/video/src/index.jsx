import React from 'react';
import {registerRoot,Composition,Series,Folder,Still,AbsoluteFill,Img,staticFile} from 'remotion';
import {Problem} from './Problem';
import {Brand} from './Brand';
import {Clarity} from './Clarity';
import {Preserve} from './Preserve';
import {Start} from './Start';
import {Workflow} from './Workflow';
import {Audio} from '@remotion/media';

const Intro = () => <>
<Audio src={staticFile('ambient.wav')} premountFor={30} volume={0.6}/>
<Series>
  <Series.Sequence name="旧版本" durationInFrames={210} premountFor={30}><Problem/></Series.Sequence>
  <Series.Sequence name="项目交接" durationInFrames={180} premountFor={30}><Brand/></Series.Sequence>
  <Series.Sequence name="当前入口" durationInFrames={330} premountFor={30}><Clarity/></Series.Sequence>
  <Series.Sequence name="保留证据" durationInFrames={180} premountFor={30}><Preserve/></Series.Sequence>
  <Series.Sequence name="开始使用" durationInFrames={180} premountFor={30}><Start/></Series.Sequence>
</Series>
</>;
const Cover = () => <AbsoluteFill><Img src={staticFile('cover.svg')} style={{width:'100%',height:'100%'}}/></AbsoluteFill>;
const Root = () => <>
  <Composition id="HandoffIntro" component={Intro} durationInFrames={1080} fps={30} width={1920} height={1080}/>
  <Composition id="Workflow" component={Workflow} durationInFrames={100} fps={20} width={960} height={480}/>
  <Still id="SocialCard" component={Cover} width={1280} height={640}/>
  <Folder name="Scenes">
    <Composition id="Problem" component={Problem} durationInFrames={210} fps={30} width={1920} height={1080}/>
    <Composition id="Brand" component={Brand} durationInFrames={180} fps={30} width={1920} height={1080}/>
    <Composition id="Clarity" component={Clarity} durationInFrames={330} fps={30} width={1920} height={1080}/>
    <Composition id="Preserve" component={Preserve} durationInFrames={180} fps={30} width={1920} height={1080}/>
    <Composition id="Start" component={Start} durationInFrames={180} fps={30} width={1920} height={1080}/>
  </Folder>
</>;
registerRoot(Root);
