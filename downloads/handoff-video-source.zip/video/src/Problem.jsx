import React from 'react';
import {useCurrentFrame, interpolate} from 'remotion';
import {Scene,Paper,C} from './common';

export const Problem = () => {
  const frame=useCurrentFrame();
  return <Scene duration={210} chapter="01 / 旧状态">
    <div style={{position:'absolute',left:118,top:170,fontSize:128,fontWeight:800,letterSpacing:-7}}>新对话，旧版本？</div>
    <Paper label="旧交接 · 2026-09-15" version="v1.1" detail="生成演示，然后发布" style={{left:145,top:380,rotate:'-3deg',opacity:interpolate(frame,[10,30],[0,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})}}/>
    <Paper label="当前版本清单" version="v2.4" detail="候选已存在，待人工验收" accent style={{right:145,top:380,rotate:'2deg',opacity:interpolate(frame,[40,62],[0,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})}}/>
    <div style={{position:'absolute',left:850,top:535,width:220,textAlign:'center',fontSize:104,color:'#87a460'}}>≠</div>
    <div style={{position:'absolute',left:118,top:875,fontSize:47,color:C.muted}}>过期的版本和待办，别接成下一步。</div>
  </Scene>;
};
