import React from 'react';
import {useCurrentFrame,interpolate} from 'remotion';
import {Scene,C} from './common';

export const Clarity = () => {
  const frame=useCurrentFrame();
  return <Scene duration={330} chapter="03 / 接手入口">
    <div style={{position:'absolute',left:118,top:170,fontSize:124,fontWeight:800,letterSpacing:-5}}>先核实，再交接。</div>
    <div style={{position:'absolute',left:120,top:395,width:475,fontSize:54,lineHeight:1.85,color:C.muted}}>当前入口变短。<br/>原始证据保留。<br/>细节按任务展开。</div>
    <div style={{position:'absolute',left:690,top:365,width:1115,height:530,background:C.white,border:`2px solid ${C.line}`,borderRadius:22,padding:'25px 38px',boxSizing:'border-box'}}>
      {[
        ['01','当前状态','v2.4 候选 · 待人工验收'],
        ['02','下一步','请负责人审阅候选'],
        ['03','关键约束','原始数据和冻结结果保留'],
        ['04','证据入口','版本清单 → 评估记录'],
      ].map(([num,label,value],i)=><div key={num} style={{display:'flex',alignItems:'center',gap:23,height:116,borderBottom:i<3?`1px solid ${C.line}`:undefined,opacity:interpolate(frame,[15+i*28,35+i*28],[0,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})}}>
        <div style={{fontFamily:'Arial',fontSize:32,color:'#718c55',width:43}}>{num}</div>
        <div style={{fontSize:47,fontWeight:700,width:225}}>{label}</div>
        <div style={{fontSize:45,color:C.muted,whiteSpace:'nowrap'}}>{value}</div>
      </div>)}
    </div>
  </Scene>;
};
