import React from 'react';
import {AbsoluteFill, useCurrentFrame, interpolate, Easing} from 'remotion';
import {titleFont,displayFont,monoFont,bodyFont} from './typography';
export {titleFont,displayFont,monoFont};

export const C = {paper:'#f3f4ed',ink:'#172d25',muted:'#627366',green:'#c4ed80',line:'#cad3c3',white:'#ffffff'};
export const font = bodyFont;
export const Scene = ({children, duration, dark=false, chapter}) => {
  const frame = useCurrentFrame();
  return <AbsoluteFill style={{backgroundColor:dark?C.ink:C.paper,color:dark?C.paper:C.ink,fontFamily:font}}>
    <div style={{position:'absolute',left:118,top:65,fontFamily:displayFont,fontWeight:400,fontSize:43,letterSpacing:-1}}>handoff<span style={{color:dark?C.green:'#648935'}}>.</span></div>
    <div style={{position:'absolute',right:118,top:73,fontSize:26,color:dark?'#a6b49e':C.muted}}>项目交接 / {chapter}</div>
    <AbsoluteFill style={{opacity:interpolate(frame,[0,14,duration-11,duration-1],[0,1,1,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp',easing:Easing.bezier(0.33,0,0.2,1)}),translate:interpolate(frame,[0,22],['0px 26px','0px 0px'],{extrapolateLeft:'clamp',extrapolateRight:'clamp',easing:Easing.bezier(0.16,1,0.3,1)}),scale:interpolate(frame,[0,22],[0.992,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp',easing:Easing.bezier(0.16,1,0.3,1)})}}>{children}</AbsoluteFill>
    <div style={{position:'absolute',right:118,bottom:57,fontSize:23,color:dark?'#a6b49e':C.muted,fontFamily:monoFont}}>github.com/jidekaixin2dian/handoff</div>
  </AbsoluteFill>;
};
export const Paper = ({label,version,detail,style,accent=false}) => <div style={{position:'absolute',width:650,height:425,background:C.white,border:`2px solid ${C.line}`,borderRadius:22,padding:'38px 48px',boxSizing:'border-box',...style}}>
  <div style={{fontSize:36,color:C.muted,marginBottom:38}}>{label}</div>
  <div style={{fontFamily:monoFont,fontWeight:500,fontSize:108,letterSpacing:-5,color:accent?'#527c29':C.ink}}>{version}</div>
  <div style={{fontSize:45,marginTop:26,lineHeight:1.5}}>{detail}</div>
</div>;
