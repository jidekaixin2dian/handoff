import React from 'react';
import {AbsoluteFill, useCurrentFrame, interpolate, Easing} from 'remotion';

export const C = {paper:'#f3f4ed',ink:'#172d25',muted:'#627366',green:'#c4ed80',line:'#cad3c3',white:'#ffffff'};
export const font = '"Microsoft YaHei", "Noto Sans CJK SC", Arial, sans-serif';
export const Scene = ({children, duration, dark=false, chapter}) => {
  const frame = useCurrentFrame();
  return <AbsoluteFill style={{backgroundColor:dark?C.ink:C.paper,color:dark?C.paper:C.ink,fontFamily:font}}>
    <div style={{position:'absolute',left:118,top:70,fontFamily:'Arial,sans-serif',fontWeight:700,fontSize:32,letterSpacing:1}}>handoff<span style={{color:dark?C.green:'#648935'}}>.</span></div>
    <div style={{position:'absolute',right:118,top:73,fontSize:26,color:dark?'#a6b49e':C.muted}}>项目交接 / {chapter}</div>
    <AbsoluteFill style={{opacity:interpolate(frame,[0,14,duration-13,duration-1],[0,1,1,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'}),translate:interpolate(frame,[0,22],['0px 22px','0px 0px'],{extrapolateRight:'clamp',easing:Easing.bezier(0.16,1,0.3,1)})}}>{children}</AbsoluteFill>
    <div style={{position:'absolute',right:118,bottom:57,fontSize:25,color:dark?'#a6b49e':C.muted,fontFamily:'Arial,sans-serif'}}>github.com/jidekaixin2dian/handoff</div>
  </AbsoluteFill>;
};
export const Paper = ({label,version,detail,style,accent=false}) => <div style={{position:'absolute',width:650,height:425,background:C.white,border:`2px solid ${C.line}`,borderRadius:22,padding:'38px 48px',boxSizing:'border-box',...style}}>
  <div style={{fontSize:36,color:C.muted,marginBottom:38}}>{label}</div>
  <div style={{fontFamily:'Arial,sans-serif',fontWeight:800,fontSize:118,letterSpacing:-5,color:accent?'#527c29':C.ink}}>{version}</div>
  <div style={{fontSize:45,marginTop:26,lineHeight:1.5}}>{detail}</div>
</div>;
