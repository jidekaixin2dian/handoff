import React from 'react';
import {AbsoluteFill,useCurrentFrame,interpolate} from 'remotion';
import {C,font} from './common';

export const Workflow = () => {
  const frame=useCurrentFrame();
  return <AbsoluteFill style={{background:C.paper,fontFamily:font,color:C.ink,padding:'48px 56px',boxSizing:'border-box'}}>
    <div style={{fontSize:40,fontWeight:700}}>交接清楚，继续做。</div>
    <div style={{display:'flex',gap:32,alignItems:'center',marginTop:50}}>
      <div style={{width:340,height:220,background:'#e4e8dd',borderRadius:14,padding:28,boxSizing:'border-box',fontSize:25,lineHeight:1.85}}>
        <div style={{color:C.muted,fontSize:20,marginBottom:15}}>旧交接</div>
        <div style={{textDecoration:'line-through',color:'#8b9483'}}>v1.1 · 生成并发布</div>
        <div>重复历史与旧待办</div>
        <div>下次又从头解释</div>
      </div>
      <div style={{fontSize:40,color:'#6f923c',width:50,textAlign:'center'}}>→</div>
      <div style={{width:410,height:220,background:C.white,border:`2px solid ${C.line}`,borderRadius:14,padding:28,boxSizing:'border-box',fontSize:25,lineHeight:1.85,opacity:interpolate(frame,[10,30],[0,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})}}>
        <div style={{color:'#628a39',fontSize:20,marginBottom:15}}>核对后的当前入口</div>
        <div>v2.4 候选 · 待人工验收</div>
        <div>下一步：请负责人审阅</div>
        <div>原始证据按任务索引</div>
      </div>
    </div>
  </AbsoluteFill>;
};
