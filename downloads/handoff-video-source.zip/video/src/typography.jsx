import {loadFont} from '@remotion/fonts';
import {staticFile} from 'remotion';

export const fontsReady=Promise.all([
  loadFont({family:'HandoffTitle',url:staticFile('fonts/notoserifsc-500.woff2'),weight:'500'}),
  loadFont({family:'HandoffDisplay',url:staticFile('fonts/newsreader-400.woff2'),weight:'400'}),
  loadFont({family:'HandoffMono',url:staticFile('fonts/ibmplexmono-400.woff2'),weight:'400'}),
  loadFont({family:'HandoffMono',url:staticFile('fonts/ibmplexmono-500.woff2'),weight:'500'}),
  loadFont({family:'HandoffBody',url:staticFile('fonts/notosanssc-400.woff2'),weight:'400'}),
  loadFont({family:'HandoffBody',url:staticFile('fonts/notosanssc-600.woff2'),weight:'600'}),
]);

export const titleFont='"HandoffTitle", serif';
export const displayFont='"HandoffDisplay", serif';
export const monoFont='"HandoffMono", monospace';
export const bodyFont='"HandoffBody", sans-serif';
