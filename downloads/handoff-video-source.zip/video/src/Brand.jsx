import React from 'react';
import {Scene,C} from './common';

export const Brand = () => <Scene duration={180} dark chapter="02 / 项目交接">
  <div style={{position:'absolute',left:112,top:225,fontFamily:'Arial,sans-serif',fontSize:306,fontWeight:800,letterSpacing:-18}}>handoff<span style={{color:C.green}}>.</span></div>
  <div style={{position:'absolute',left:125,top:620,fontSize:108,fontWeight:700,letterSpacing:-5}}>换个对话，项目接着做。</div>
  <div style={{position:'absolute',left:128,top:815,fontSize:52,color:'#b9c7b0'}}>一个小 skill，把当前状态说清楚。</div>
  <svg width="285" height="320" viewBox="0 0 256 256" style={{position:'absolute',right:142,top:265}}>
    <rect x="35" y="23" width="147" height="183" rx="17" fill="#668457" transform="rotate(-12 108 118)"/>
    <rect x="68" y="30" width="147" height="183" rx="17" fill={C.paper}/>
    <path d="M94 70h67M94 102h91" stroke="#9caa91" strokeWidth="11" strokeLinecap="round"/>
    <path d="M90 162h98m-24-21 24 21-24 21" fill="none" stroke="#628a39" strokeWidth="12" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
</Scene>;
