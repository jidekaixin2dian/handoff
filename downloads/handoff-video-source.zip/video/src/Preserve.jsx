import React from 'react';
import {useCurrentFrame,interpolate,Easing} from 'remotion';
import {Scene,C,titleFont} from './common';

const EvidenceLine = ({children,from}) => {
  const frame=useCurrentFrame();
  return <div style={{display:'flex',alignItems:'center',gap:28,height:118,
    opacity:interpolate(frame,[from,from+16],[0,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp'}),
    translate:interpolate(frame,[from,from+20],['0px 14px','0px 0px'],{extrapolateLeft:'clamp',extrapolateRight:'clamp',easing:Easing.bezier(0.16,1,0.3,1)})}}>
    <span aria-hidden="true" style={{width:4,height:36,background:'#628f36',flexShrink:0}}/>
    <span>{children}</span>
  </div>;
};

export const Preserve = () => <Scene duration={180} chapter="04 / 保留边界">
  <div style={{position:'absolute',left:118,top:158,fontFamily:titleFont,fontSize:124,fontWeight:500,letterSpacing:-1}}>精简文本，保留证据。</div>
  <div style={{position:'absolute',left:118,top:420,fontSize:64,lineHeight:1.15}}>
    <EvidenceLine from={22}>原始数据、冻结评估、人工评分</EvidenceLine>
    <EvidenceLine from={32}>独有决策、已有修改、未跟踪文件</EvidenceLine>
    <EvidenceLine from={42}>未请求清理，就不顺手删文件</EvidenceLine>
  </div>
  <div style={{position:'absolute',left:118,top:855,fontSize:44,color:C.muted}}>技术检查通过 ≠ 人工接受 · 旧发布计划 ≠ 新授权</div>
</Scene>;
