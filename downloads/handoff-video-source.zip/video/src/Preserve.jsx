import React from 'react';
import {Scene,C} from './common';

export const Preserve = () => <Scene duration={180} chapter="04 / 保留边界">
  <div style={{position:'absolute',left:118,top:170,fontSize:124,fontWeight:800,letterSpacing:-5}}>精简文本，保留证据。</div>
  <div style={{position:'absolute',left:118,top:420,fontSize:64,lineHeight:1.85}}>
    <div><span style={{color:'#628f36'}}>✓</span> 原始数据、冻结评估、人工评分</div>
    <div><span style={{color:'#628f36'}}>✓</span> 独有决策、已有修改、未跟踪文件</div>
    <div><span style={{color:'#628f36'}}>✓</span> 未请求清理，就不顺手删文件</div>
  </div>
  <div style={{position:'absolute',left:118,top:855,fontSize:44,color:C.muted}}>技术检查通过 ≠ 人工接受 · 旧发布计划 ≠ 新授权</div>
</Scene>;
