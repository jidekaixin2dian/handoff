import React from 'react';
import {Scene,C,font,titleFont,monoFont} from './common';

export const Start = () => <Scene duration={180} dark chapter="05 / 接着做">
  <div style={{position:'absolute',left:118,top:198,fontFamily:titleFont,fontSize:132,fontWeight:500,letterSpacing:-1}}>下一位，接着做。</div>
  <div style={{position:'absolute',left:118,top:465,width:1678,padding:'64px 50px',border:'2px solid #54644c',borderRadius:18,boxSizing:'border-box',background:'#20382c',fontSize:37,fontFamily:monoFont,color:C.green}}>
    <div>npx skills add jidekaixin2dian/handoff --skill handoff --agent codex</div>
  </div>
  <div style={{position:'absolute',left:122,top:760,fontFamily:monoFont,fontSize:52}}>$handoff <span style={{fontFamily:font,color:'#c2cdbb'}}>我要换个新对话继续这个项目。</span></div>
  <div style={{position:'absolute',left:122,top:880,fontSize:43,color:'#a6b69f'}}>MIT 开源 · 纯指令 skill · 安装命令已核对</div>
</Scene>;
