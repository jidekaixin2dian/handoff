# Video fonts

Downloaded from the Google Fonts CSS API, with the characters used by this composition plus printable ASCII. Each font retains its adjacent SIL OFL license; font files are not covered by the project MIT license.

After changing text, run `python tools/fetch_fonts.py` to update character coverage. Font files are loaded locally, so preview and rendering do not require access to Google Fonts.
