# handoff 介绍视频源文件

安装依赖：`npm ci`。预览：`npm run studio`。导出：`npm run render`。

Remotion 默认使用 Chrome Headless Shell；也可以给渲染命令传入 `--browser-executable` 和 `--chrome-mode=chrome-for-testing`，使用兼容的已安装浏览器。字体优先 Microsoft YaHei，其他系统建议安装 Noto Sans CJK SC。

36 秒 / 1920×1080 / 30 fps。原创合成背景音由 tools/music.py 生成，无旁白。流程示意使用虚构项目。

MIT License，2026 jidekaixin2dian。
