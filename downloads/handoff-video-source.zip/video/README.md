# handoff 介绍视频源文件

36 秒 / 1920×1080 / 30 fps。

安装依赖：`npm ci`。预览：`npm run studio`。导出：`npm run render`。

Remotion 默认使用 Chrome Headless Shell；也可通过 `--browser-executable` 和 `--chrome-mode=chrome-for-testing` 使用兼容的已安装浏览器。

字体和音乐已包含在 public/，预览与导出不需要在线获取素材。字体为 Newsreader、Noto Serif SC、Noto Sans SC 和 IBM Plex Mono，采用 SIL OFL；许可证位于 public/fonts/。字体文件不适用项目 MIT 许可证。

原创配乐由 tools/music_v3.py 生成。重新生成配乐需要 Python、numpy 和项目内的 FFmpeg；正常预览、导出不需要 Python。修改画面文字后，可运行 tools/fetch_fonts.py 更新字体子集。

项目源代码采用 MIT License，2026 jidekaixin2dian。
