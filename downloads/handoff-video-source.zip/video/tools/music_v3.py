"""Original 36-second swung electric-piano score. Requires numpy and bundled FFmpeg."""
from pathlib import Path
import json
import subprocess
import wave
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
RATE, DURATION, BPM = 44100, 36, 100
BEAT = 60 / BPM
RNG = np.random.default_rng(314159)
mix = np.zeros((RATE * DURATION, 2), dtype=np.float64)


def hz(note):
    return 440 * 2 ** ((note - 69) / 12)


def time_axis(length):
    return np.arange(round(length * RATE)) / RATE


def add(sound, start, level, pan=0):
    offset = round(start * RATE)
    if offset < 0 or offset >= len(mix):
        return
    count = min(len(sound), len(mix) - offset)
    angle = (pan + 1) * np.pi / 4
    mix[offset:offset + count, 0] += sound[:count] * level * np.cos(angle)
    mix[offset:offset + count, 1] += sound[:count] * level * np.sin(angle)


def envelope(t, length, attack, decay):
    return (1 - np.exp(-t / attack)) * np.exp(-t / decay) * np.clip((length - t) / .12, 0, 1)


def keys(note, length=2.4, soft=False):
    t = time_axis(length)
    phase = 2 * np.pi * hz(note) * t
    modulation = (.22 if soft else .55) * np.exp(-t * 5) * np.sin(2 * phase)
    tone = .82 * np.sin(phase + modulation) + .13 * np.sin(2 * phase) * np.exp(-t * 2)
    tone += .035 * np.sin(3 * phase) * np.exp(-t * 5)
    return tone * envelope(t, length, .012, 1.3 if soft else .9)


def bass(note, length=.65):
    t = time_axis(length)
    phase = 2 * np.pi * hz(note) * t
    return (np.sin(phase) + .13 * np.sin(2 * phase)) * envelope(t, length, .014, .32)


def kick():
    t = time_axis(.32)
    phase = 2 * np.pi * (49 * t + 55 * .025 * (1 - np.exp(-t / .025)))
    return np.sin(phase) * envelope(t, .32, .003, .07)


def brush(length=.14, hat=False):
    t = time_axis(length)
    noise = RNG.normal(0, .6, len(t))
    # High-pass noise for the shaker; smooth the brush to avoid a sharp snare crack.
    if hat:
        noise = noise - np.roll(noise, 1)
    else:
        noise = np.convolve(noise, np.ones(7) / 7, mode='same')
    return noise * envelope(t, length, .004, .023 if hat else .05)


# Close voicings in D major: add9 / minor9 / major9 / suspended dominant.
chords = {
    'D': (38, [57, 61, 64, 66]),
    'B': (35, [57, 61, 62, 66]),
    'G': (31, [54, 57, 59, 62]),
    'A': (33, [55, 59, 61, 66]),
    'F': (30, [57, 61, 64, 68]),
    'D6': (38, [57, 59, 62, 66]),
}
progression = ['D', 'D', 'B', 'G', 'A', 'F', 'B', 'G', 'D', 'A', 'G', 'B', 'A', 'D', 'D6']
for bar, chord in enumerate(progression):
    start = bar * 4 * BEAT
    root, notes = chords[chord]
    quiet = 24 <= start < 30
    opening = start < 7
    closing = start >= 33.6
    # A slight rolled attack and off-beat chord answer, rather than a repeated drone.
    for j, note in enumerate(notes):
        add(keys(note, 3 if closing else 2.4, quiet), start + j * .013,
            .058 if quiet else .066, (j - 1.5) * .23)
        if not closing and bar % 2 == 1:
            add(keys(note, 1.3, True), start + 2.65 * BEAT + j * .009, .026, (1.5 - j) * .23)
    bass_pattern = [(0, root), (2, root + 12)] if opening or quiet else [(0, root), (1.75, root + 7), (2.5, root + 12), (3.6, root + 7)]
    for position, note in bass_pattern:
        add(bass(note), start + position * BEAT, .11 if quiet else .15)
    if not quiet and not closing:
        groove = .5 if opening else (1 if start < 13 or start >= 30 else .74)
        for position in (0, 2.5):
            add(kick(), start + position * BEAT, .12 * groove)
        for position in (1, 3):
            add(brush(), start + position * BEAT + .012, .10 * groove, -.12)
        for step in range(8):
            swing = .043 if step % 2 else 0
            velocity = .014 if step % 2 else .021
            add(brush(.08, True), start + step * BEAT / 2 + swing + RNG.uniform(-.008, .008),
                velocity * groove, .38 if step % 2 else -.35)

# Sparse pentatonic phrases, with rests and a small answer in the second half.
phrases = [(2.1, 69), (2.75, 66), (4.2, 64), (7.03, 73), (7.65, 69), (8.55, 66),
           (10.35, 64), (11.25, 66), (13.06, 69), (14.75, 66), (17.4, 64),
           (19.25, 66), (20.15, 69), (22.05, 73), (30.05, 73), (30.65, 69),
           (31.55, 66), (32.45, 64), (33.63, 74)]
for start, note in phrases:
    add(keys(note, 1.8, True), start, .055, .16 * np.sin(start))

# Three restrained key accents match the new evidence-row entrances at 24 seconds.
for start, note in [(24 + 22 / 30, 66), (24 + 32 / 30, 69), (24 + 42 / 30, 73)]:
    add(keys(note, 1.7, True), start, .032, -.25)

# A short, quiet stereo room and two cross-delays leave space between attacks.
dry = mix.copy()
for delay, gain in [(0.071, .075), (.119, .055), (BEAT * .75, .12), (BEAT * 1.5, .065)]:
    shift = round(delay * RATE)
    mix[shift:] += dry[:-shift, ::-1] * gain
t = np.arange(len(mix)) / RATE
mix *= (np.minimum(t / .25, 1) * np.clip((DURATION - t) / 1.35, 0, 1))[:, None]
mix *= .76 / np.max(np.abs(mix))
raw = ROOT / 'out' / 'music-v3-raw.wav'
with wave.open(str(raw), 'wb') as output:
    output.setnchannels(2)
    output.setsampwidth(2)
    output.setframerate(RATE)
    output.writeframes(np.round(mix * 32767).astype('<i2').tobytes())

ffmpeg = ROOT / 'node_modules/@remotion/compositor-win32-x64-msvc/ffmpeg.exe'
analysis = subprocess.run([str(ffmpeg), '-hide_banner', '-i', str(raw), '-af',
    'loudnorm=I=-18:TP=-2:LRA=8:print_format=json', '-c:a', 'pcm_s16le', '-f', 'null', 'NUL'],
    capture_output=True, text=True, check=True).stderr
stats = json.loads(analysis[analysis.rfind('{'):analysis.rfind('}') + 1])
filter_value = ('loudnorm=I=-18:TP=-2:LRA=8:linear=true:'
    f'measured_I={stats["input_i"]}:measured_TP={stats["input_tp"]}:'
    f'measured_LRA={stats["input_lra"]}:measured_thresh={stats["input_thresh"]}:'
    f'offset={stats["target_offset"]}')
destination = ROOT / 'public/music-v3.wav'
subprocess.run([str(ffmpeg), '-v', 'error', '-y', '-i', str(raw), '-af', filter_value,
    '-ar', str(RATE), '-c:a', 'pcm_s16le', str(destination)], check=True)
with wave.open(str(destination), 'rb') as audio:
    samples = np.frombuffer(audio.readframes(audio.getnframes()), dtype='<i2').reshape(-1, 2) / 32768
    metrics = {'duration_seconds': len(samples) / RATE, 'channels': audio.getnchannels(),
               'sample_rate': audio.getframerate(), 'peak_dbfs': float(20 * np.log10(np.max(np.abs(samples)))),
               'clipped_samples': int(np.count_nonzero(np.abs(samples) >= .9999)),
               'bpm': BPM, 'source': 'Original synthesis in tools/music_v3.py',
               'normalization_target_lufs': -18,
               'section_rms_dbfs': [float(20 * np.log10(np.sqrt(np.mean(samples[int(a*RATE):int(b*RATE)]**2))))
                                    for a, b in [(0, 7), (7, 13), (13, 24), (24, 30), (30, 36)]]}
assert metrics['duration_seconds'] == DURATION and metrics['clipped_samples'] == 0
(ROOT / 'out/audio-v3-validation.json').write_text(json.dumps(metrics, indent=2), encoding='utf-8')
print(json.dumps(metrics, indent=2))
