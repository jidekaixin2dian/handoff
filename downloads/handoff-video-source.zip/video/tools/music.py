from pathlib import Path
import math
import struct
import wave

rate=44100
duration=36
path=Path(__file__).resolve().parents[1]/'public'/'ambient.wav'
roots=[164.8138,146.8324,130.8128,164.8138]
data=bytearray()
peak=0
for n in range(rate*duration):
    t=n/rate
    section=min(3,int(t//9))
    local=t-section*9
    blend=min(1,local/1.4)
    old=roots[max(0,section-1)]
    root=roots[section]
    def chord(hz):
        return sum(math.sin(2*math.pi*hz*ratio*t)*amp for ratio,amp in [(1,.075),(1.259921,.04),(1.498307,.038),(2,.017)])
    pad=chord(old)*(1-blend)+chord(root)*blend
    beat=t%0.75
    pulse=math.sin(2*math.pi*82.4069*t)*math.exp(-beat*28)*.052
    swell=0.82+0.18*math.sin(2*math.pi*.11*t)
    envelope=min(1,t/1.8,max(0,(duration-t)/2.4))
    value=(pad*swell+pulse)*envelope
    peak=max(peak,abs(value))
    data.extend(struct.pack('<h',int(max(-1,min(1,value))*32767)))
with wave.open(str(path),'wb') as output:
    output.setnchannels(1)
    output.setsampwidth(2)
    output.setframerate(rate)
    output.writeframes(data)
print(f'Original synthesized background: {duration}s, {rate}Hz, peak={peak:.4f}')
