from pathlib import Path
import hashlib,json,re,urllib.parse,urllib.request

root=Path(__file__).resolve().parents[1]
out=root/'public/fonts';out.mkdir(exist_ok=True)
chars=set(chr(i) for i in range(32,127))
for p in (root/'src').glob('*.jsx'):
    chars.update(p.read_text(encoding='utf-8'))
text=''.join(sorted(c for c in chars if not c.isspace()))
families=[('Noto Serif SC','notoserifsc',[500]),('Newsreader','newsreader',[400]),('IBM Plex Mono','ibmplexmono',[400,500]),('Noto Sans SC','notosanssc',[400,600])]
records=[]
def fetch(url):
    req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36'})
    return urllib.request.urlopen(req,timeout=40).read()
for family,slug,weights in families:
    license_data=fetch('https://raw.githubusercontent.com/google/fonts/main/ofl/'+slug+'/OFL.txt')
    (out/(slug+'-OFL.txt')).write_bytes(license_data)
    for weight in weights:
        query=urllib.parse.urlencode({'family':family+':wght@'+str(weight),'text':text,'display':'block'})
        css=fetch('https://fonts.googleapis.com/css2?'+query).decode()
        urls=re.findall(r'url\((https://[^)]+)\)',css)
        assert len(urls)==1,(family,weight,css)
        data=fetch(urls[0]);assert data[:4] in [b'wOF2',b'\x00\x01\x00\x00'],(family,data[:4])
        filename=slug+'-'+str(weight)+('.woff2' if data[:4]==b'wOF2' else '.ttf')
        (out/filename).write_bytes(data)
        records.append({'family':family,'weight':weight,'file':filename,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'source':urls[0]})
(out/'manifest.json').write_text(json.dumps({'text':text,'fonts':records},ensure_ascii=False,indent=2),encoding='utf-8')
(out/'README.md').write_text('# Video fonts\n\nDownloaded from the Google Fonts CSS API, with the characters used by this composition plus printable ASCII. Each font retains its adjacent SIL OFL license; font files are not covered by the project MIT license.\n\nAfter changing text, run `python tools/fetch_fonts.py` to update character coverage. Font files are loaded locally, so preview and rendering do not require access to Google Fonts.\n',encoding='utf-8')
print(json.dumps([{'family':r['family'],'weight':r['weight'],'bytes':r['bytes']} for r in records]))
